<?php
include('admin.php')
?>